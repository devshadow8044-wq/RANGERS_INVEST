# Plan du projet RANGERS INVEST / RANGERS RG

## But et limites
Créer une application web mobile-first autonome, hébergeable comme service Node.js sur Katabump, avec pages client, API Express et panel administrateur séparé. Le site est servi depuis un seul serveur et une base SQLite ; il ne contient pas le projet Vercel existant et aucune connexion ne sera tentée à l’adresse de panel fournie. Le serveur écoute sur le port `PORT` donné par l’hébergeur, avec `20010` comme valeur de secours.

Les comptes utilisent un numéro de téléphone, un pays et un mot de passe haché. Les pays sont le Sénégal, le Mali, la Côte d’Ivoire et le Bénin. Les nouveaux comptes restent en attente jusqu’à vérification manuelle par un administrateur. Les dépôts sont des demandes en attente portant une référence de paiement ; seul l’administrateur peut créditer le compte après vérification réelle, dans une transaction SQL auditée. Les retraits réservent le solde disponible, puis sont marqués comme payés uniquement après versement réel ; un rejet libère la réserve. Les moyens de paiement mobiles sont filtrés par pays, sans intégration de versement ou encaissement automatique. Aucun connecteur de paiement, aucune clé marchand, aucune offre ni aucun taux de rendement n’est inventé.

L’administrateur peut créer et modifier une offre, la laisser en brouillon ou la suspendre. La publication est refusée tant que ne sont pas fournis la description, les montants minimum/maximum, la durée, les frais, les modalités de retrait, les risques, le mode de résultat/rendement et une référence de validation réelle saisie par l’admin. Le code n’authentifie pas la réalité de cette référence et ne remplace aucun contrôle juridique. Le catalogue client ne renvoie que les fiches publiées.

Connexion client et connexion administrateur sont distinctes. Les permissions sont contrôlées sur le serveur. Les mots de passe utilisent bcrypt, les formulaires une protection CSRF, les cookies HTTP-only et Secure en production, les mutations sont validées et limitées en débit. Un secret de session et un administrateur initial sont requis par variables d’environnement privées. Si l’accès public n’est pas en HTTPS, les écrans de connexion et les opérations financières restent désactivés. L’authentification OTP/SMS, MFA admin et récupération autonome ne sont pas configurées.

## Direction visuelle

**Mouvement** : reproduction soignée de l’application mobile montrée dans les captures, sans recoloration autorisée.

**Principes** : priorité au téléphone ; surfaces blanches et gris clair ; photos automobiles et cadrages issus des références ; couleurs d’icônes, badges et navigation correspondantes ; pas de fausses données financières.

**Couleurs** : reprendre les gris et blancs des écrans Accueil/Moi, le bleu des prix et sélections, le noir des actions et le gris très clair de la barre inférieure. Préserver la palette sombre translucide et le fond automobile pour Connexion/Inscription ainsi que le bandeau automobile sombre de l’écran Équipe. Conserver les teintes beige/doré, lavande/bleu et violet/mauve des niveaux, sans pourcentage de commission non validé.

**Disposition** : pages étroites pensées pour un écran Android, contenu vertical, cartes arrondies, actions compactes et barre fixe à quatre onglets : Accueil, Produit, Équipe, Moi. Les écrans dépôt et carte gardent leur traitement clair/bleu de référence.

**Interactions** : formulaires courts, libellés visibles, confirmation explicite, statut lisible et actions financières prudentes. Un dépôt ne devient crédit qu’après revue administrateur ; un retrait achevé exige une référence réelle.

**Animation** : pas d’animation décorative ; respecter les préférences de réduction du mouvement.

**Typographie** : Roboto système Android avec fallback Arial/sans-serif ; tailles et poids alignés sur les captures et lisibles sur petits écrans.

**Essence de marque** : espace mobile RANGERS INVEST pour les membres du Sénégal, Mali, Côte d’Ivoire et Bénin ; direct, familier, prudent.

**Voix** : français simple, concis et explicite. Exemples : « Votre demande est en attente de vérification. » / « Le compte sera crédité après confirmation du paiement. »

**Logo** : conserver le pictogramme visible dans la capture Moi, recadré sans recoloration.

**Couleur signature** : gris ardoise clair, bleu réservé aux accents et montants du catalogue.

## Structure des fichiers

- `server.js` : configuration HTTP, sécurité, API, pages statiques, sessions, droits et routes admin.
- `server/db.js` et `server/schema.sql` : ouverture SQLite, migrations additives, tables membres, sessions, dépôts/retraits, registre, offres et audit.
- `public/` : fichiers HTML mobiles, CSS, JavaScript client et images fournis.
- `scripts/backup.js` : sauvegarde locale de la base, à télécharger ensuite hors hébergement.
- `tests/` : tests métier et scénario HTTP complet sur base temporaire isolée.
- `docs/` : installation Katabump, variables d’environnement et limites de déploiement.
- `data/` : base SQLite persistante, exclue du ZIP et du dépôt.

## Déploiement
`package.json` à la racine, script `npm start`, écoute `0.0.0.0:$PORT` et secours `20010`. SQLite est le backend initial autonome. La base doit être sauvegardée hors de l’instance. Les connexions nécessitent un nom de domaine HTTPS réel, la création d’un administrateur et le déploiement des bons secrets ; les opérations de paiement manuel exigent vérification hors plateforme. Les conditions financières publiées sont celles saisies par l’admin et nécessitent une validation indépendante avant leur diffusion.
