# État de RANGERS INVEST — Vercel

## Interface
- [x] Pages françaises mobile-first, navigation, images et palette conservées dans `public/` ; aucune refonte visuelle apportée pour cette migration.
- [x] Pages publiques et espaces dédiés : accueil, inscription/connexion, produits, équipe, Moi, dépôts, retraits, historique et administration.
- [x] Aucun solde, rendement ou produit fictif n’est prérempli.

## API et persistance
- [x] L’application Express utilise les requêtes PostgreSQL Neon asynchrones ; aucune route Vercel ne dépend du fichier SQLite.
- [x] Schéma PostgreSQL et persistance des membres, sessions, produits, demandes, ledger et audit.
- [x] Opérations composites de dépôt/retrait exécutées dans des transactions ; retraits idempotents, vérification sous verrou, transitions admin protégées.
- [x] Premier administrateur créé une seule fois via `/admin-setup.html` et le secret temporaire `ADMIN_SETUP_TOKEN`.
- [x] L’application échoue fermé si `DATABASE_URL` ou `SESSION_SECRET` manque ; elle ne crée pas de compte par défaut.
- [ ] Tests contre une vraie branche/base Neon dédiée ; la connexion Neon n’a pas été vérifiée faute d’accès.

## Déploiement et prérequis
- [x] Entrée Vercel `index.js`, configuration du schéma inclus au bundle et guide Vercel + Neon.
- [ ] Dépôt Git autorisé et projet Vercel à relier ; aucun dépôt distant ni liaison Vercel n’est disponible dans ce dossier.
- [ ] Ajouter `DATABASE_URL`, `SESSION_SECRET` et `ADMIN_SETUP_TOKEN` dans Vercel, puis déployer en Preview.
- [ ] Valider les parcours sur une base de test, créer l’admin et supprimer le jeton temporaire avant Production.
- [ ] Aucun compte marchand/API Orange Money, Moov ou Wave n’est raccordé ; traitement des paiements manuel uniquement.
- [ ] Faire vérifier les obligations applicables aux offres et opérations dans les quatre pays avant toute collecte d’argent réel.

## Vérifications locales
- [x] Vérifications syntaxiques et `npm run vercel-build` réussis.
- [x] `npm test` passe : tests unitaires historiques isolés, validation du jeton admin et scénario de refus fermé sans Neon.
- [x] Les pages et images statiques restent identiques à la version Katabump ; seul le nouvel écran admin initial est ajouté.
- [ ] Pas de test de bout en bout PostgreSQL ni de déploiement/publication confirmés.
