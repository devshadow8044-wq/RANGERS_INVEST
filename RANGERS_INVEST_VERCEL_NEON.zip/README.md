# RANGERS INVEST — version Vercel

Version mobile du site RANGERS INVEST préparée pour Vercel avec une API Express et une base PostgreSQL Neon reliée au projet. L’interface et les images de la référence sont dans `public/`; les routes serveur sont dans `server.js`; le schéma persistant est `server/schema.postgres.sql`.

## Fonctionnalités conservées

- Pages françaises mobile-first : accueil, connexion/inscription, produits, équipe, Moi, dépôts, retraits, historique et administration.
- Pays disponibles : Sénégal, Mali, Côte d’Ivoire et Bénin ; méthodes déclarées par pays selon le code.
- Comptes membres en attente d’activation admin ; connexion et panel administrateur distincts.
- Soldes et historique calculés à partir d’un registre serveur ; dépôts en attente de vérification ; retraits réservés et payés manuellement après traitement réel.
- Création d’offres en brouillon ; publication seulement après saisie des conditions demandées.
- Première création administrateur via `/admin-setup.html`, protégée par un jeton secret temporaire Vercel et autorisée une seule fois.

## Mise en route locale

Prérequis : Node.js 20+ et npm. Pour une base Neon de développement séparée, remplir les secrets dans un fichier `.env` local non versionné, puis lancer :

```bash
npm ci
npm test
npm run vercel-build
npm start
```

Variables nécessaires à l’exécution persistante : `DATABASE_URL` (Neon), `SESSION_SECRET` (au moins 32 caractères), et `ADMIN_SETUP_TOKEN` (jeton aléatoire temporaire utilisé seulement pour le premier compte admin). Après la création du premier admin, supprimer `ADMIN_SETUP_TOKEN` de l’environnement concerné.

## Configuration et déploiement

Voir [`docs/DEPLOIEMENT_VERCEL.md`](docs/DEPLOIEMENT_VERCEL.md) pour connecter le dépôt à Vercel, relier l’intégration Neon, configurer les secrets, créer l’admin et valider Preview. Cette copie n’a pas encore été reliée au compte Vercel de l’utilisateur et n’est pas annoncée comme déployée.

## Limites financières importantes

Aucune passerelle Orange Money, Moov ou Wave n’est connectée : la vérification des encaissements et le paiement des retraits restent manuels. Aucune offre ni promesse de rendement n’est publiée par défaut. Le code ne remplace pas les autorisations, contrats, procédures de sauvegarde, avis juridique ou validation des comptes marchands nécessaires dans chaque pays.

Les tests locaux couvrent des validations métier de l’ancienne couche isolée et le refus fermé quand la base manque. Aucun test PostgreSQL de bout en bout ni aucune connexion à Neon n’ont été exécutés sans une base de test fournie. Ne pas exécuter les migrations ou scénarios destructifs contre les données de production.
