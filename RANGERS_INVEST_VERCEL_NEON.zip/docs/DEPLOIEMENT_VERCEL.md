# Mise en ligne de RANGERS INVEST sur Vercel + Neon

## Ce que contient cette version

Le site statique est conservé dans `public/`. La racine `index.js` expose l’application Express au runtime Node.js de Vercel. L’API utilise PostgreSQL Neon avec `DATABASE_URL`, fourni par l’intégration Neon du Marketplace Vercel. Les comptes, sessions, catalogue, demandes, écritures de solde et journaux sont stockés dans cette base, pas dans un fichier local. Les écritures financières et leurs journaux sont exécutés dans des transactions PostgreSQL, avec verrouillage lors des vérifications sensibles.

Les dépôts restent à vérifier manuellement dans le compte marchand réel avant leur validation. Les retraits restent manuels et ne sont marqués payés qu’après le versement réel et la saisie de sa référence. Aucun opérateur de paiement n’est connecté automatiquement.

## Étapes dans Vercel

1. Importer ce dossier comme nouveau projet depuis un dépôt Git autorisé, ou fournir l’accès au projet Vercel déjà existant. Ne pas écraser un autre site sans vérifier son URL et le dépôt source.
2. Dans le Marketplace Vercel, installer l’intégration **Neon** et la relier à ce projet. Choisir le bon environnement/région et vérifier que `DATABASE_URL` est bien associée au projet, à Preview et à Production.
3. Dans les variables d’environnement Vercel, créer `SESSION_SECRET` avec au moins 32 caractères aléatoires. Créer aussi `ADMIN_SETUP_TOKEN` comme secret aléatoire d’au moins 32 caractères. Ne pas placer ces valeurs dans Git, dans un fichier public ou dans une conversation. Redéployer après les avoir ajoutées.
4. Tester d’abord une Preview reliée à une branche/base Neon dédiée. Le premier appel à l’API crée le schéma PostgreSQL idempotent. Vérifier `https://<adresse-preview>/api/health` : le résultat attendu est HTTP 200 avec `{"status":"ok","database":"ready"}`.
5. Lorsque le domaine HTTPS est actif et la base correctement reliée, ouvrir `https://<adresse>/admin-setup.html`. Saisir le `ADMIN_SETUP_TOKEN`, choisir un identifiant et un mot de passe administrateur d’au moins 16 caractères. Cette route est limitée et, après création du premier admin, ne peut plus créer un autre compte.
6. Supprimer immédiatement `ADMIN_SETUP_TOKEN` des variables de cet environnement Vercel, puis redéployer. Se connecter ensuite via `/admin-login.html`. Ne pas supprimer `SESSION_SECRET` ni `DATABASE_URL`.
7. Tester inscription, activation, sessions, catalogue, dépôts et retraits sur une base de test séparée. Vérifier les données et restaurations avant toute bascule publique.

## Variables

- `DATABASE_URL` : injectée par Neon quand l’intégration Marketplace est reliée au projet.
- `SESSION_SECRET` : secret long et aléatoire pour signer les cookies de session.
- `ADMIN_SETUP_TOKEN` : secret temporaire, utilisé uniquement pour créer le premier administrateur puis supprimé.
- `NODE_ENV` : réglé par Vercel. Aucun port ou fichier SQLite n’est nécessaire en production.

## Limites et sécurité

Le code et les vérifications locales ne prouvent pas encore qu’une connexion à une base Neon réelle a fonctionné. Une vérification d’intégration doit être faite sur une base/branche de test Neon distincte ; ne lance pas des tests destructifs contre Production. L’administration et les écritures ne seront réellement utilisables qu’après configuration de la base et des secrets, puis création du compte admin.

Orange Money, Moov et Wave ne sont pas raccordés comme passerelles. Le libellé d’une méthode dans un formulaire ne constitue ni un paiement automatisé, ni une preuve de paiement. Les produits ne doivent être publiés qu’avec des conditions vérifiées et autorisées dans les pays concernés. Aucun rendement, dépôt, retrait ou solde fictif n’est prérempli.

La limitation de tentatives de connexion actuelle est locale à une instance de fonction. Elle ne remplace pas un limiteur partagé ni des règles WAF lorsque le trafic est distribué. Avant d’ouvrir les inscriptions largement, configure une protection réseau adaptée et surveille les erreurs de connexion.

## État de publication

Aucune connexion au compte Vercel, au dépôt source ou à Neon n’a été fournie ici. Le code préparé n’a pas été publié ; il n’existe donc pas encore d’URL de production confirmée.
